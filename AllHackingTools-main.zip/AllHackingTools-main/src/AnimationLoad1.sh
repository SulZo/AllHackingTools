clear
g="\033[1;32m"
r="\033[1;31m"
b="\033[1;34m"
w="\033[0m"
o="\033[1;33m"
printf "\e[1;92m"

cd
cd
cd AllHackingTools 
clear
cd
cd
cd AllHackingTools
mv MainMenu.py /data/data/com.termux/files/home/AllHackingTools/Tool
cd src
python3 CheckFolder.py
