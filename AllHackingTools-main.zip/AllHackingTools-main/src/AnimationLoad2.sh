clear
g="\033[1;32m"
r="\033[1;31m"
b="\033[1;34m"
w="\033[0m"
o="\033[1;33m"
printf "\e[1;92m"

printf "\n#aaaaaaaaaaaaaaaaaaaaa Loading .\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.01
clear
printf "\n#aaaaaaaaaaaaaaaaaaaaa Loading ..\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.01
clear
printf "\n##aaaaaaaaaaaaaaaaaaaa Loading ...\n"
sleep 0.01
clear
printf "\n##aaaaaaaaaaaaaaaaaaaa Loading .\n"
sleep 0.05
clear
printf "\n###aaaaaaaaaaaaaaaaaaa Loading ..\n"
clear
printf "\n###aaaaaaaaaaaaaaaaaaa Loading ...\n"
clear
printf "\n####aaaaaaaaaaaaaaaaaa Loading .\n"
sleep 0.01
clear
printf "\n####aaaaaaaaaaaaaaaaaa Loading ..\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.01
clear
printf "\n#####aaaaaaaaaaaaaaaaa Loading ...\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.01
clear
printf "\n#####aaaaaaaaaaaaaaaaa Loading .\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.02
clear
printf "\n######aaaaaaaaaaaaaaaa Loading ..\n"
sleep 0.02
clear
printf "\n#######aaaaaaaaaaaaaaa Loading ...\n"
sleep 0.01
clear
printf "\n#######aaaaaaaaaaaaaaa Loading .\n"
sleep 0.01
clear
printf "\n#########aaaaaaaaaaaaa Loading ..\n"
clear
printf "\n##########aaaaaaaaaaaa Loading ...\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.01
clear
printf "\n###########aaaaaaaaaaa Loading .\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.01
clear
printf "\n###########aaaaaaaaaaa Loading ..\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.01
clear
printf "\n############aaaaaaaaaa Loading ...\n"
sleep 0.03
clear
printf "\n#############aaaaaaaaa Loading .\n"
sleep 0.01
clear
printf "\n##############aaaaaaaa Loading ..\n"
sleep 0.05
clear
printf "\n###############aaaaaaa Loading ...\n"
clear
printf "\n################aaaaaa Loading .\n"
sleep 0.005
clear
printf "\n################aaaaaa Loading ..\n"
sleep 0.01
clear
printf "\n#################aaaaa Loading ...\n"
sleep 0.01
clear
printf "\n#################aaaaa Loading .\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.01
clear
printf "\n##################aaaa Loading ..\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.01
clear
help
printf "\n###################aaa Loading ...\n"
printf "\nPlease wait a moment ..!\n"
sleep 0.01
clear
printf "\n###################aaa Loading .\n"
sleep 0.006
clear
printf "\n###################aaa Loading ..\n"
sleep 0.006
clear
printf "\n####################aa Loading ...\n"
leep 0.1
clear
printf "\n###################### DONE!\n"
cd
cd 
cd AllHackingTools 
bash src/CheckWifi.sh
sleep 2
clear
sleep 0.1
cd
cd
cd AllHackingTools
python3 .check/Configuration.py
