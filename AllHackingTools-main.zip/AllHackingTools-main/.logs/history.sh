cd
cd
nano .zsh_history
