apt-get install git
apt-get install python
apt-get install npm
pip install pyngrok
pip install pgrep
cd
cd AllHackingTools
git clone https://github.com/Bhaviktutorials/shark
cd shark
chmod +x *
./setup
cd
cd AllHackingTools
git clone https://github.com/htr-tech/zphisher.git
cd
cd AllHackingTools
git clone https://github.com/AbirHasan2005/ShellPhish
cd ShellPhish 
chmod +x * 
cd 
cd AllHackingTools 
git clone https://github.com/hangetzzu/saycheese
cd saycheese
cd
cd
cd AllHackingTools 
git clone https://github.com/iinc0gnit0/BlackPhish
cd BlackPhish
./install.sh
cd 
cd 
cd AllHackingTools
git clone https://github.com/mishakorzik/Mask-Phish.Termux
cd
cd
cd AllHackingTools
git clone https://github.com/thewhiteh4t/seeker.git
cd seeker
cd
cd
cd AllHackingTools
git clone https://github.com/DeepSociety/AIOPhish
cd AIOPhish
bash install-termux.sh
cd
cd
cd AllHackingTools
git clone https://github.com/Viralmaniar/I-See-You.git
cd I-See-You
chmod u+x ISeeYou.sh
cd
cd 
cd AllHackingTools
git clone https://github.com/DarkSecDevelopers/HiddenEye.git
chmod 777 HiddenEye
cd HiddenEye
cd
cd
cd AllHackingTools
git clone https://github.com/An0nUD4Y/blackeye
cd
cd
cd AllHackingTools






